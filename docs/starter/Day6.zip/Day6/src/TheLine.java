import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;


public class TheLine extends GraphicsProgram {

	public void run() {
		// your code here...
	}

}
