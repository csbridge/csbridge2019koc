import stanford.karel.*;

public class Place100 extends Karel {
	
	public void run() {
		// your code here...
	}

}
