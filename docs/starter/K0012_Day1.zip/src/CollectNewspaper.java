import stanford.karel.*;

public class CollectNewspaper extends Karel {
	
	public void run(){
		// your code here..
	}
}
