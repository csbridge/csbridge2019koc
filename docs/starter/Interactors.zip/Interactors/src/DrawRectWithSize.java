import acm.graphics.GRect;
import acm.program.*;

import java.awt.Color;
import java.awt.event.*;

import javax.swing.*;

public class DrawRectWithSize extends GraphicsProgram {
	private static final double SMALL_SIZE = 10;
	private static final double LARGE_SIZE = 40;
	private static final double MEDIUM_SIZE = 20;
	private JRadioButton smallButton;
	private JRadioButton mediumButton;
	private JRadioButton largeButton;
	private JCheckBox checkbox;
	private JSlider slider;
	private JComboBox combo;

	/**
	 * This program creates a five-pointed star every time the user clicks the
	 * mouse on the canvas
	 */
	public void init() {
		// Your code starts here
		smallButton = new JRadioButton("Small");
		mediumButton = new JRadioButton("Medium");
		largeButton = new JRadioButton("Large");
		add(smallButton, NORTH);
		add(mediumButton, NORTH);
		add(largeButton, NORTH);
		ButtonGroup bg = new ButtonGroup();
		bg.add(smallButton);
		bg.add(mediumButton);
		bg.add(largeButton);
		mediumButton.setSelected(true);
		
		add(new JLabel("Small"), SOUTH);
		slider = new JSlider(1,3,2);
		add(slider, SOUTH);
		add(new JLabel("Large"), SOUTH);
		
		add(new JButton("Clear"), SOUTH);
		checkbox = new JCheckBox("isFilled");
		add(checkbox, SOUTH);
		combo = new JComboBox();
		combo.addItem("Blue");
		combo.addItem("Green");
		combo.addItem("Red");
		combo.setSelectedIndex(0);
		add(combo,NORTH);
	
		// Your code ends here
		addActionListeners();
		addMouseListeners();
	}

	/* Called whenever the user clicks the mouse */
	public void mouseClicked(MouseEvent e) {
		// Your code starts here
		//double size = getCurrentSize();
		double size = getSliderSize();
		GRect rec = new GRect(size, size);
		add(rec, e.getX(), e.getY());
		rec.setFilled(checkbox.isSelected());
		rec.setFillColor(getCurrentColor());
		// Your code ends here
	}

	private double getSliderSize() {
		double answer = 0;
		if (slider.getValue() == 1) {
			answer = SMALL_SIZE;
		} else if (slider.getValue() == 2) {
			answer = MEDIUM_SIZE;
		} else if (slider.getValue() == 3) {
			answer = LARGE_SIZE;
		}
		return answer;
	}
	private Color getCurrentColor() {
		String colorSelect = (String) combo.getSelectedItem();
		if (colorSelect.equals("Blue")) {
			return Color.BLUE;
			
		} else if (colorSelect.equals("Green")) {
			return Color.GREEN;
		} else  {
			return Color.RED;
		}
	}
	private double getCurrentSize() {
		double answer = 0;
		// Your code starts here
		if (smallButton.isSelected()) {
			answer = SMALL_SIZE;
		} else if (mediumButton.isSelected()) {
			answer = MEDIUM_SIZE;
		} else if (largeButton.isSelected()) {
			answer = LARGE_SIZE;
		}
		
		// Your code ends here
		return answer;
	}

	public void actionPerformed(ActionEvent e) {
		// Handle the clear button:
		// Your code starts here
		if (e.getActionCommand().equals("Clear"))
			removeAll();
		// Your code ends here
	}
}
